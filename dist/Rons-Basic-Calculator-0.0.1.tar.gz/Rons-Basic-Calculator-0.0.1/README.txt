This is a Basic Calculator to add, Subtract, multiply or divide Numbers

Published to the PyPi